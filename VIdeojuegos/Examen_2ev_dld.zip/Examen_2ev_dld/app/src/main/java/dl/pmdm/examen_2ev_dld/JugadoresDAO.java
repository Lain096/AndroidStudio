package dl.pmdm.examen_2ev_dld;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class JugadoresDAO {

    SQLiteDatabase db;

    Context context;

    public JugadoresDAO(SQLiteDatabase db){


        this.db = db;
    }


    public List<Jugadores> getListJugadores(){

        List<Jugadores> lista = new ArrayList<>();
        Cursor cs = db.rawQuery("SELECT * FROM JUGADORES", null);

        if (cs.getCount() == 0){
            return null;
        }else{
            while (cs.moveToNext()){
                Jugadores jugador = new Jugadores();
                jugador.setId(cs.getInt(cs.getColumnIndex("id")));
                jugador.setNombre(cs.getString(cs.getColumnIndex("nombre")));
                jugador.setEquipo(cs.getString(cs.getColumnIndex("equipo")));
                jugador.setDorsal(cs.getInt(cs.getColumnIndex("dorsal")));
                jugador.setConferencia(cs.getString(cs.getColumnIndex("conferencia")));
                jugador.setPos1(cs.getString(cs.getColumnIndex("pos1")));
                jugador.setPos2(cs.getString(cs.getColumnIndex("pos2")));
                jugador.setPos3(cs.getString(cs.getColumnIndex("pos3")));
                jugador.setImg(cs.getString(cs.getColumnIndex("img")));

                lista.add(jugador);


            }
            return lista;
        }

    }


    public void insertarJugador(){

        db.execSQL("INSERT INTO JUGADORES (nombre, equipo, dorsal, conferencia, pos1, pos2, pos3, img) VALUES ('Lebron James', 'Los Angeles Lakers' , 6, 'Oeste', 'SF' , 'PF' , null, 'james')");
        db.execSQL("INSERT INTO JUGADORES (nombre, equipo, dorsal, conferencia, pos1, pos2, pos3, img) VALUES ('james Harden', 'Philadelphia 76ers' , 1, 'Este', 'PG' , 'SG' , 'SF', 'harden')");
        db.execSQL("INSERT INTO JUGADORES (nombre, equipo, dorsal, conferencia, pos1, pos2, pos3, img) VALUES ('Nikola Jokic', 'Denver Nuggets' , 15, 'Oeste', 'C' , null , null, 'jokic')");

    }

    public void filtrarJugadoresporPosicionYconferencia(){

            db.execSQL("SELECT * FROM JUGADORES WHERE conferencia = 'Oeste' AND (pos1 = 'SF' OR pos2 = 'SF' OR pos3 = 'SF')");
    }
}
