package dl.pmdm.examen_2ev_dld;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class JugadoresAdapter extends RecyclerView.Adapter<JugadoresAdapter.JugadoresViewHolder>{


    private List<Jugadores> listaJugadores;
    private Context context;


    public JugadoresAdapter(List<Jugadores> jugadoresList, Context context) {
        this.listaJugadores = jugadoresList;
        this.context = context;
    }


    @NonNull
    @Override
    public JugadoresViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.jugadores_recycler, parent, false);

        return new JugadoresViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull JugadoresAdapter.JugadoresViewHolder holder, int position) {

        holder.equipo.setText(listaJugadores.get(position).getEquipo());
        holder.nombre.setText(listaJugadores.get(position).getNombre());
        String img = listaJugadores.get(position).getImg();


        if(listaJugadores.get(position).getId() % 2 == 1) {

            holder.itemView.setBackgroundColor(Color.CYAN);
        }
      //  holder.imagen.setBackgroundResource(holder.getResources().getIdentifier(img, "drawable", context.getPackageName()));
        holder.imagen.setImageResource(context.getResources().getIdentifier(img, "drawable", context.getPackageName()));


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Bundle b = new Bundle();



                androidx.fragment.app.FragmentManager fragmentManager = ((AppCompatActivity) context).getSupportFragmentManager();

                b.putSerializable("jugador", listaJugadores.get(position));
                b.putInt("posicion", position);



                fragmentManager.beginTransaction().replace(R.id.fragmentContainerView, FragmentInfoJugadores.class, b).commit();


            }
        });

    }

    @Override
    public int getItemCount() {
        return listaJugadores.size();
    }


    public class JugadoresViewHolder extends RecyclerView.ViewHolder {


        private ImageView imagen;
        private TextView nombre, equipo;
        public JugadoresViewHolder(@NonNull View itemView) {
            super(itemView);


            imagen = itemView.findViewById(R.id.imgRecycler);
            nombre = itemView.findViewById(R.id.nombreRecycler);
            equipo = itemView.findViewById(R.id.equipoRecycler);


        }
    }
}
