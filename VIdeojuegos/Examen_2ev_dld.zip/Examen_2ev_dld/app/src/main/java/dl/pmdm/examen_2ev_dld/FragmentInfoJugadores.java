package dl.pmdm.examen_2ev_dld;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FragmentInfoJugadores#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentInfoJugadores extends Fragment {

    private Jugadores jugador;
    private ImageView btnAtras, imgJugador;
    private TextView nombre, equipo, conferencia, dorsal, posicion;

    public static FragmentInfoJugadores newInstance(String param1, String param2) {
        FragmentInfoJugadores fragment = new FragmentInfoJugadores();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment


        View v = inflater.inflate(R.layout.fragment_info_jugadores, container, false);


        if (getArguments() != null){

            jugador = (Jugadores)getArguments().getSerializable("jugador");

        }



        nombre = v.findViewById(R.id.fragmentNombreJugador);
        equipo = v.findViewById(R.id.fragmentoEquipo);
        conferencia = v.findViewById(R.id.fragmentoConferenciaJugador);
        dorsal = v.findViewById(R.id.fragmentoDorsal);
        posicion = v.findViewById(R.id.fragmentoPosicion);
        imgJugador = v.findViewById(R.id.fragmentImgJugador);

        btnAtras = v.findViewById(R.id.fragmentoBoton);


        nombre.setText(jugador.getNombre());
        equipo.setText(jugador.getEquipo());
        conferencia.setText("(Conferencia " + jugador.getConferencia() + ")");
        dorsal.setText(String.valueOf(jugador.getDorsal()));

        posicion.setText(jugador.getPos1() + " " + jugador.getPos2() + " " + jugador.getPos3());
        imgJugador.setImageResource(MainActivity.global.getResources().getIdentifier(jugador.getImg(), "drawable", MainActivity.global.getPackageName()));


        btnAtras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getActivity().getSupportFragmentManager().beginTransaction().remove(FragmentInfoJugadores.this).commit();

            }
        });


        return v;
    }
}