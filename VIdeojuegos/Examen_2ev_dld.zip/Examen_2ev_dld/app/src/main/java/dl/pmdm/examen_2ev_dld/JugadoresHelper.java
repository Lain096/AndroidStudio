package dl.pmdm.examen_2ev_dld;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class JugadoresHelper extends SQLiteOpenHelper {
    public JugadoresHelper(@Nullable Context context) {
        super(context, "Jugadores.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {


        db.execSQL("CREATE TABLE JUGADORES (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT, equipo TEXT, dorsal INTEGER, conferencia TEXT, pos1 TEXT, pos2 TEXT, pos3 TEXT,img TEXT)");

        JugadoresDAO jugadoresDAO = new JugadoresDAO(db);
        jugadoresDAO.insertarJugador();



    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
