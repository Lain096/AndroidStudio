package dl.pmdm.examen_2ev_dld;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private SharedPreferences prefs;
    private CheckBox este, oeste;
    private Button btnFiltrar;

    private Spinner spinner;
    public static Context global;

    List<Jugadores> jugadoresList;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        global = this;
        spinner = findViewById(R.id.spinner);
        este = findViewById(R.id.checkbox_Este);
        oeste = findViewById(R.id.checkbox_Oeste);
        btnFiltrar = findViewById(R.id.botonFiltrar);

        JugadoresHelper jh = new JugadoresHelper(this);
        SQLiteDatabase db = jh.getWritableDatabase();


        prefs = getSharedPreferences("file_fondo", MODE_PRIVATE);
        JugadoresDAO dao = new JugadoresDAO(db);

        jugadoresList = dao.getListJugadores();

        recyclerView = findViewById(R.id.recycler);
        recyclerView.setAdapter(new JugadoresAdapter(jugadoresList, this));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.spinner_items, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                String escogido = parent.getItemAtPosition(position).toString();

                switch (escogido.toLowerCase()){

                    case "todas las posiciones":
                        adapterPosiciones(jugadoresList);
                        break;
                    case "pg":
                        adapterPosiciones(posPG());
                        break;
                    case "sg":
                        adapterPosiciones(posSG());
                        break;
                    case "sf":
                        adapterPosiciones(posSF());
                        break;
                    case "pf":
                        adapterPosiciones(posPF());
                        break;
                    case "c":
                        adapterPosiciones(posC());
                        break;
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        btnFiltrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    if (este.isChecked() && oeste.isChecked()){

                        adapterPosiciones(jugadoresList);
                    }else if (este.isChecked()){

                        adapterPosiciones(jugadoresEste());
                    }else if (oeste.isChecked()){

                        adapterPosiciones(jugadoresOeste());
                    }
            }
        });




    }

    public List<Jugadores> jugadoresEste(){
        List<Jugadores> jugadores = new ArrayList<>();

        for(Jugadores j : jugadoresList){

            if(j.getConferencia().toLowerCase().equals("este")){
                jugadores.add(j);
            }
        }
        return jugadores;
    }
    public List<Jugadores> jugadoresOeste(){
        List<Jugadores> jugadores = new ArrayList<>();

        for(Jugadores j : jugadoresList){

            if(j.getConferencia().toLowerCase().equals("oeste")){
                jugadores.add(j);
            }
        }
        return jugadores;
    }


    public void adapterPosiciones(List<Jugadores> lista){

        recyclerView.setAdapter(new JugadoresAdapter(lista, this));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        recyclerView.getAdapter().notifyDataSetChanged();
    }

    public List<Jugadores> posPG() {

        String a = "PG";
        List<Jugadores> lista = new ArrayList<>();

        for (Jugadores j : jugadoresList) {

            if (a.equals(j.getPos1()) || a.equals(j.getPos2()) || a.equals(j.getPos3())) {

                lista.add(j);
            }
        }

        return lista;


    }

    public List<Jugadores> posSG() {
        String a = "SG";

        List<Jugadores> lista = new ArrayList<>();

        for (Jugadores j : jugadoresList) {

            if (a.equals(j.getPos1()) || a.equals(j.getPos2()) || a.equals(j.getPos3())) {

                lista.add(j);
            }
        }

        return lista;

    }

    public List<Jugadores> posSF() {

        String a = "SF";
        List<Jugadores> lista = new ArrayList<>();

        for (Jugadores j : jugadoresList) {

            if (a.equals(j.getPos1()) || a.equals(j.getPos2()) || a.equals(j.getPos3())) {

                lista.add(j);
            }
        }

        return lista;

    }

    public List<Jugadores> posPF() {

        String a = "PF";
        List<Jugadores> lista = new ArrayList<>();



        for (Jugadores j : jugadoresList) {

            if (a.equals(j.getPos1()) || a.equals(j.getPos2()) || a.equals(j.getPos3())) {

                lista.add(j);
            }
        }

        return lista;

    }
    public List<Jugadores> posC() {

        String a = "C";
        List<Jugadores> lista = new ArrayList<>();

        for (Jugadores j : jugadoresList) {

            if (a.equals(j.getPos1()) || a.equals(j.getPos2()) || a.equals(j.getPos3())) {

                lista.add(j);
            }
        }

        return lista;

    }



}